package sit.tu_varna.bg.project.enums;

/**
 * Енум на всички поддържани фигури
 */
public enum Figures {
    CIRCLE,ELLIPSE,RECTANGLE,POLYGON,LINE,POLYLINE
}
