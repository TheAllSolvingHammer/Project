package sit.tu_varna.bg.project.menu.commands;

import sit.tu_varna.bg.project.contracts.MenuCommand;
import sit.tu_varna.bg.project.shapes.ShapeManager;

import java.util.Scanner;
/**
 * Клас за командата Еrase
 */
public class EraseCommand implements MenuCommand {
    /**
     * Метод обработващ командата
     * @param command командата която се подава
     */
    @Override
    public void execute(String command) {
        if(command==null || command.isEmpty()){
            return;
        }
        ShapeManager manageShape= ShapeManager.getInstance();
        Scanner scanner = new Scanner(command);
        int index;
        scanner.useDelimiter(" ");
        if(!scanner.hasNext()) {
            System.out.println("empty instructions");
            return;
        }
        String s1=scanner.next();
        if(!s1.equals("erase")){
            System.out.println("Wrong arguments");
            return;
        }
        if(!scanner.hasNextInt()){
            System.out.println("Wrong arguments");
            return;
        }
        index= scanner.nextInt();
        if(index<0){
            System.out.println("Wrong index");
            return;
        }
        manageShape.removeShape(index);
    }
}
