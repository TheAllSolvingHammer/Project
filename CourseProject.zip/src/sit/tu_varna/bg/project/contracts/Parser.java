package sit.tu_varna.bg.project.contracts;


public interface Parser {
    String parseText();

}
