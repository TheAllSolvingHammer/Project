package sit.tu_varna.bg.project.contracts;


public interface FileManage {
    void execute();
    boolean isSvgExtension();

}
