package sit.tu_varna.bg.project.contracts;


public interface MenuCommand {
    void execute(String command);
}
