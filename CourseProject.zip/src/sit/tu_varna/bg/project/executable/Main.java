package sit.tu_varna.bg.project.executable;

import sit.tu_varna.bg.project.Application;


public class Main {

    public static void main(String[] args)  {
        /*
        rectangle brown pink 10 200 300 500 400";
        D:\\testSvg\\fig.svg
        */
        Application.runProgram();

    }
}
